#!/usr/bin/env python3
import argparse
import html
import json
import os
import re
import urllib.parse
import urllib.request
import xml.etree.ElementTree as ET
from datetime import datetime, timedelta, timezone
from email.utils import parsedate_to_datetime
from pathlib import Path
import subprocess

TZ_VN = timezone(timedelta(hours=7))

VN_FEEDS = [
    "https://vnexpress.net/rss/tin-moi-nhat.rss",
    "https://tuoitre.vn/rss/tin-moi-nhat.rss",
    "https://thanhnien.vn/rss/home.rss",
    "https://vietnamnet.vn/rss/trang-chu.rss",
    "https://laodong.vn/rss/home.rss",
]

INTL_FEEDS = {
    "ai": "https://news.google.com/rss/search?q=artificial+intelligence&hl=en-US&gl=US&ceid=US:en",
    "politics": "https://news.google.com/rss/search?q=world+politics&hl=en-US&gl=US&ceid=US:en",
    "economy": "https://news.google.com/rss/search?q=global+economy&hl=en-US&gl=US&ceid=US:en",
}

# Fallback search feeds (tìm kiếm theo truy vấn) dùng khi feed chính lỗi/rỗng
VN_FALLBACK_FEEDS = [
    "https://news.google.com/rss/search?q=Vi%E1%BB%87t+Nam+tin+m%E1%BB%9Bi+nh%E1%BA%A5t&hl=vi&gl=VN&ceid=VN:vi",
    "https://news.google.com/rss/search?q=kinh+t%E1%BA%BF+Vi%E1%BB%87t+Nam&hl=vi&gl=VN&ceid=VN:vi",
    "https://news.google.com/rss/search?q=y+t%E1%BA%BF+Vi%E1%BB%87t+Nam&hl=vi&gl=VN&ceid=VN:vi",
]

INTL_FALLBACK_FEEDS = {
    "ai": "https://news.google.com/rss/search?q=latest+AI+news&hl=en-US&gl=US&ceid=US:en",
    "politics": "https://news.google.com/rss/search?q=international+politics+latest&hl=en-US&gl=US&ceid=US:en",
    "economy": "https://news.google.com/rss/search?q=global+markets+latest&hl=en-US&gl=US&ceid=US:en",
}

COMMEMORATIVE_FILE = "/Users/xitrum/.openclaw/workspace-zalo-agent/data/commemorative-days-vi.json"


def fetch(url: str, timeout: int = 20) -> bytes:
    req = urllib.request.Request(url, headers={"User-Agent": "Mozilla/5.0"})
    with urllib.request.urlopen(req, timeout=timeout) as r:
        return r.read()


def clean_text(s: str) -> str:
    if not s:
        return ""
    s = html.unescape(s)
    s = re.sub(r"<[^>]+>", " ", s)
    s = re.sub(r"\s+", " ", s).strip()
    return s


def parse_date(s: str):
    if not s:
        return None
    s = s.strip()
    try:
        dt = parsedate_to_datetime(s)
        if dt.tzinfo is None:
            dt = dt.replace(tzinfo=timezone.utc)
        return dt
    except Exception:
        pass
    for fmt in ["%Y-%m-%dT%H:%M:%S%z", "%Y-%m-%d %H:%M:%S", "%a, %d %b %Y %H:%M:%S %z"]:
        try:
            dt = datetime.strptime(s, fmt)
            if dt.tzinfo is None:
                dt = dt.replace(tzinfo=timezone.utc)
            return dt
        except Exception:
            continue
    return None


def parse_items(raw: bytes):
    root = ET.fromstring(raw)
    items = []

    channel = root.find("channel")
    if channel is not None:
        for it in channel.findall("item"):
            title = clean_text((it.findtext("title") or "").strip())
            link = (it.findtext("link") or "").strip()
            pub = (it.findtext("pubDate") or it.findtext("published") or "").strip()
            desc = clean_text((it.findtext("description") or "").strip())
            items.append({"title": title, "link": link, "pub": pub, "summary": desc})
    else:
        ns = "{http://www.w3.org/2005/Atom}"
        for it in root.findall(f"{ns}entry"):
            title = clean_text((it.findtext(f"{ns}title") or "").strip())
            lk = it.find(f"{ns}link")
            link = (lk.attrib.get("href", "") if lk is not None else "").strip()
            pub = (it.findtext(f"{ns}updated") or it.findtext(f"{ns}published") or "").strip()
            desc = clean_text((it.findtext(f"{ns}summary") or it.findtext(f"{ns}content") or "").strip())
            items.append({"title": title, "link": link, "pub": pub, "summary": desc})

    return items


def short_summary(text: str, n: int = 150) -> str:
    if not text:
        return "Chưa có mô tả ngắn từ nguồn RSS."
    text = text.strip()
    if len(text) <= n:
        return text
    cut = text[:n].rsplit(" ", 1)[0].strip()
    return (cut or text[:n]).strip() + "..."


def pick_recent(feed_url: str, hours: int = 24, top: int = 3):
    cutoff = datetime.now(timezone.utc) - timedelta(hours=hours)
    items = []
    try:
        raw = fetch(feed_url)
        for it in parse_items(raw):
            title = (it.get("title") or "").strip()
            link = (it.get("link") or "").strip()
            dt = parse_date(it.get("pub", ""))
            if not title or not link or not dt:
                continue
            if dt.astimezone(timezone.utc) < cutoff:
                continue
            items.append({
                "title": title,
                "link": link,
                "summary": it.get("summary", ""),
                "publishedAt": dt.astimezone(timezone.utc).isoformat(),
            })
    except Exception:
        return []

    dedup = {}
    for it in items:
        key = (it["link"].strip().lower(), it["title"].strip().lower())
        if key not in dedup or it["publishedAt"] > dedup[key]["publishedAt"]:
            dedup[key] = it
    return sorted(dedup.values(), key=lambda x: x["publishedAt"], reverse=True)[:top]


def pick_recent_multi(feed_urls, hours: int = 24, top: int = 3):
    all_items = []
    for u in feed_urls:
        all_items.extend(pick_recent(u, hours=hours, top=top))
    dedup = {}
    for it in all_items:
        key = (it.get("link", "").strip().lower(), it.get("title", "").strip().lower())
        if key not in dedup or it.get("publishedAt", "") > dedup[key].get("publishedAt", ""):
            dedup[key] = it
    return sorted(dedup.values(), key=lambda x: x.get("publishedAt", ""), reverse=True)[:top]


def get_weather(city: str):
    import time
    import logging
    
    # Map Vietnamese city names to English equivalents for better API compatibility
    CITY_ALIASES = {
        "hanoi": ["Ha Noi", "Hanoi", "HÀ NỘI", "HÀ NOI", "HaNoi"],
        "halong": ["Ha Long", "Halong", "HẠ LONG", "Hạ Long", "HaLong"],
        "hochiminh": ["Ho Chi Minh", "HCMC", "TP.HCM", "Sài Gòn", "Ho Chi Minh City"],
        "danang": ["Da Nang", "Đà Nẵng"],
        "hue": ["Huế", "Hue"],
        "daLat": ["Đà Lạt", "Da Lat", "Dalat"],
        "cantho": ["Can Tho", "Cần Thơ"],
        "haiPhong": ["Hai Phong", "Hải Phòng"],
        "vinh": ["Vinh", "Tp Vinh"],
        "quyNhon": ["Quy Nhơn", "Quy Nhon"],
        "nhaTrang": ["Nha Trang", "Nha Trang"],
        "vungTau": ["Vũng Tàu", "Vung Tau"],
    }
    
    def normalize_city_name(city_input):
        """Normalize city name to common forms"""
        normalized = city_input.strip().lower()
        for standard, variants in CITY_ALIASES.items():
            for variant in variants:
                if normalized == variant.lower():
                    return standard
        return normalized
    
    def fetch_weather_data(location, timeout=20, max_retries=3):
        """Fetch weather data with retries and proper error handling"""
        for attempt in range(max_retries):
            try:
                url = "https://wttr.in/" + urllib.parse.quote(location) + "?format=j1"
                
                # Add more specific headers to mimic browser requests
                req = urllib.request.Request(
                    url, 
                    headers={
                        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36",
                        "Accept": "application/json",
                        "Accept-Language": "en-US,en;q=0.9",
                    }
                )
                
                with urllib.request.urlopen(req, timeout=timeout) as r:
                    raw_data = r.read()
                    
                # Decode and parse JSON
                data = json.loads(raw_data.decode("utf-8", errors="ignore"))
                
                # Verify we got valid weather data structure
                if not isinstance(data, dict):
                    raise ValueError("Invalid response format from weather API")
                
                w0 = (data.get("weather") or [{}])[0]
                cc = (data.get("current_condition") or [{}])[0]
                
                return w0, cc
                
            except urllib.error.HTTPError as e:
                # Log specific HTTP errors but don't expose sensitive info
                logging.warning(f"Weather API HTTP error for {location}: {e.code}")
                if e.code == 429:  # Rate limited
                    wait_time = min(2 ** attempt * 2, 10)  # Exponential backoff, max 10s
                    time.sleep(wait_time)
                elif e.code >= 500:  # Server error
                    wait_time = min(2 ** attempt, 5)  # Exponential backoff
                    time.sleep(wait_time)
                else:  # Other client errors
                    break  # Don't retry for client errors like 404
            except urllib.error.URLError as e:
                # Network-related errors
                logging.warning(f"Weather API network error for {location}: {str(e)}")
                if attempt < max_retries - 1:
                    wait_time = min(2 ** attempt, 5)
                    time.sleep(wait_time)
            except json.JSONDecodeError as e:
                # Invalid JSON response
                logging.warning(f"Weather API JSON decode error for {location}: {str(e)}")
                if attempt < max_retries - 1:
                    wait_time = min(2 ** attempt, 5)
                    time.sleep(wait_time)
            except Exception as e:
                # Other exceptions
                logging.warning(f"Weather API unexpected error for {location}: {type(e).__name__}")
                if attempt < max_retries - 1:
                    wait_time = min(2 ** attempt, 5)
                    time.sleep(wait_time)
        
        return None, None
    
    # First, try with the original city name
    w0, cc = fetch_weather_data(city)
    
    # If failed, try with common aliases
    if w0 is None or cc is None:
        normalized = normalize_city_name(city)
        
        # Check if we have aliases for this city
        if normalized in CITY_ALIASES:
            for alias in CITY_ALIASES[normalized]:
                w0, cc = fetch_weather_data(alias)
                if w0 is not None and cc is not None:
                    break
        
        # If still failed, try with some common English versions
        if w0 is None or cc is None:
            english_versions = [normalized.replace(" ", "+"), normalized.replace(" ", "_")]
            for eng_version in english_versions:
                w0, cc = fetch_weather_data(eng_version)
                if w0 is not None and cc is not None:
                    break
    
    # Process the weather data if we have it
    if w0 is not None and cc is not None:
        desc = ((cc.get("weatherDesc") or [{}])[0].get("value") or "").strip()
        tmin = (w0.get("mintempC") or "?").strip()
        tmax = (w0.get("maxtempC") or "?").strip()
        hourly = w0.get("hourly") or []
        rain = 0
        for h in hourly:
            try:
                rain = max(rain, int(h.get("chanceofrain") or 0))
            except Exception:
                pass
        return f"{desc or 'Nhiều mây'}; {tmin}–{tmax}°C; mưa ~{rain}%"
    
    # If all attempts fail, return a meaningful fallback
    return "Không lấy được dữ liệu thời tiết."


def get_lunar_today_text():
    today = datetime.now(TZ_VN).strftime("%Y-%m-%d")
    cmd = ["python3", "/Users/xitrum/.openclaw/workspace/scripts/lunar_convert.py", "--solar", today, "--json"]
    try:
        out = subprocess.check_output(cmd, stderr=subprocess.STDOUT, text=True, timeout=20)
        data = json.loads(out)
        return data.get("lunar", {}).get("text", "Không rõ")
    except Exception:
        return "Không lấy được dữ liệu âm lịch."


def get_commemorative_today():
    mmdd = datetime.now(TZ_VN).strftime("%m-%d")
    p = Path(COMMEMORATIVE_FILE)
    if not p.exists():
        return ""
    try:
        data = json.loads(p.read_text(encoding="utf-8"))
        for d in data.get("days", []):
            if (d.get("date") or "") == mmdd:
                return (d.get("name") or "").strip()
    except Exception:
        return ""
    return ""


def get_weather_safe(city: str):
    # Ưu tiên script weather riêng có fallback open-meteo -> wttr
    cmd = ["python3", "/Users/xitrum/.openclaw/workspace/scripts/zalo-agent/fetch_weather_zalo.py", "--location", city]
    try:
        out = subprocess.check_output(cmd, stderr=subprocess.STDOUT, text=True, timeout=25)
        data = json.loads(out)
        if data.get("ok"):
            return data.get("text") or "🌤️ Đang cập nhật thời tiết từ nguồn dự phòng."
    except Exception:
        pass
    return "🌤️ Đang cập nhật thời tiết từ nguồn dự phòng."


def get_fuel_snapshot_text():
    cmd = ["python3", "/Users/xitrum/.openclaw/workspace/scripts/zalo-agent/fetch_vn_fuel_prices.py"]
    try:
        out = subprocess.check_output(cmd, stderr=subprocess.STDOUT, text=True, timeout=25)
        data = json.loads(out)
        if not data.get("ok"):
            return "⛽ Giá xăng: đang cập nhật từ nguồn dự phòng."
        
        # Get effective time
        effective_time = data.get("effective_time_text", "")
        
        items = data.get("items") or []
        # ưu tiên E5, RON95, DO
        pick = []
        for key in ["e5", "95", "do", "dầu"]:
            for it in items:
                p = (it.get("product") or "").lower()
                if key in p and it not in pick:
                    pick.append(it)
        if not pick:
            pick = items[:3]
        parts = []
        for it in pick[:3]:
            parts.append(f"{it.get('product','?')}: {it.get('price_vnd_per_liter','?')}")
        
        fuel_text = "⛽ Giá xăng: " + " | ".join(parts)
        if effective_time:
            fuel_text += f" ({effective_time})"
        return fuel_text
    except Exception:
        return "⛽ Giá xăng: đang cập nhật từ nguồn dự phòng."


def translate_vi(text: str) -> str:
    text = (text or "").strip()
    if not text:
        return ""
    try:
        q = urllib.parse.urlencode({
            "client": "gtx",
            "sl": "auto",
            "tl": "vi",
            "dt": "t",
            "q": text,
        })
        raw = fetch("https://translate.googleapis.com/translate_a/single?" + q, timeout=15)
        data = json.loads(raw.decode("utf-8", errors="ignore"))
        parts = []
        for seg in (data[0] or []):
            if seg and seg[0]:
                parts.append(seg[0])
        out = "".join(parts).strip()
        return out or text
    except Exception:
        return text


def source_domain(url: str) -> str:
    u = (url or "").strip()
    if not u:
        return "không rõ nguồn"
    try:
        host = urllib.parse.urlparse(u).netloc.lower().strip()
        if host.startswith("www."):
            host = host[4:]
        return host or "không rõ nguồn"
    except Exception:
        return "không rõ nguồn"


def _bulletin_edition(now_dt: datetime) -> str:
    h = now_dt.hour
    if h < 11:
        return "sáng"
    if h < 15:
        return "trưa"
    return "chiều"


def get_daily_quiz():
    """Return a deterministic daily quiz item (rotates by day)."""
    quiz_bank = [
        {
            "q": "Con gì càng to càng nhỏ?",
            "a": "Con cua (càng to thì con cua càng nhỏ).",
        },
        {
            "q": "Cái gì của bạn nhưng người khác dùng nhiều hơn bạn?",
            "a": "Tên của bạn.",
        },
        {
            "q": "Càng lấy đi thì càng lớn, là gì?",
            "a": "Cái hố.",
        },
        {
            "q": "Có cổ mà không có đầu, là gì?",
            "a": "Cái áo.",
        },
        {
            "q": "Tháng nào có 28 ngày?",
            "a": "Tất cả các tháng.",
        },
    ]
    day_idx = datetime.now(TZ_VN).timetuple().tm_yday
    item = quiz_bank[day_idx % len(quiz_bank)]
    return item["q"], item["a"]


def build_message(vn_news, intl):
    now_dt = datetime.now(TZ_VN)
    now_vn = now_dt.strftime("%d/%m %H:%M")
    edition = _bulletin_edition(now_dt)
    weather_hl = get_weather_safe("Ha Long")
    weather_hn = get_weather_safe("Ha Noi")
    fuel_line = get_fuel_snapshot_text()
    lunar = get_lunar_today_text()
    comm = get_commemorative_today()

    lines = [
        f"🌅 Bản tin {edition} Zalo — {now_vn}",
        "",
        "🌤️ Thời tiết hôm nay:",
        f"• Hạ Long: {weather_hl}",
        f"• Hà Nội: {weather_hn}",
        "",
        f"🗓️ Âm lịch hôm nay: {lunar}",
        fuel_line,
    ]

    if comm:
        lines += [f"🎉 Ngày kỷ niệm: {comm}"]

    # Put daily quiz before domestic news as requested
    quiz_q, quiz_a = get_daily_quiz()
    lines += [
        "",
        "🧩 Đố vui hôm nay:",
        f"❓ {quiz_q}",
        "(Trả lời em trong chat để em bật đáp án 😄)",
    ]

    lines += ["", "📰 Tin trong nước (24h):"]
    if vn_news:
        for i, n in enumerate(vn_news[:3], 1):
            lines += [
                f"{i}) {short_summary(n.get('summary', ''))}",
                f"🔗 Nguồn: {source_domain(n.get('link',''))}",
            ]
    else:
        lines.append("• Đang cập nhật dữ liệu tin trong nước từ nguồn dự phòng.")

    lines += ["", "🌍 Tin quốc tế:"]
    ai = intl.get("ai")
    pol = intl.get("politics")
    eco = intl.get("economy")
    if ai:
        title_vi = translate_vi(ai.get('title', ''))
        lines += [f"• 🤖 AI: {title_vi or short_summary(ai.get('summary', ''), 120)}", f"  🔗 Nguồn: {source_domain(ai.get('link',''))}"]
    else:
        lines += ["• 🤖 AI: Chưa lấy được tin."]

    if pol:
        title_vi = translate_vi(pol.get('title', ''))
        lines += [f"• 🏛️ Chính trị: {title_vi or short_summary(pol.get('summary', ''), 120)}", f"  🔗 Nguồn: {source_domain(pol.get('link',''))}"]
    else:
        lines += ["• 🏛️ Chính trị: Chưa lấy được tin."]

    if eco:
        title_vi = translate_vi(eco.get('title', ''))
        lines += [f"• 💹 Kinh tế: {title_vi or short_summary(eco.get('summary', ''), 120)}", f"  🔗 Nguồn: {source_domain(eco.get('link',''))}"]
    else:
        lines += ["• 💹 Kinh tế: Chưa lấy được tin."]

    return "\n".join(lines).strip() + "\n"


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--hours", type=int, default=24)
    ap.add_argument("--top", type=int, default=3)
    ap.add_argument("--out-dir", default="/Users/xitrum/.openclaw/workspace/reports/zalo_morning")
    args = ap.parse_args()

    vn_all = pick_recent_multi(VN_FEEDS, hours=args.hours, top=args.top)
    if not vn_all:
        # fallback web-search feeds để không trả "không lấy được dữ liệu"
        vn_all = pick_recent_multi(VN_FALLBACK_FEEDS, hours=args.hours, top=args.top)

    intl = {
        "ai": (pick_recent(INTL_FEEDS["ai"], hours=args.hours, top=1) or [None])[0],
        "politics": (pick_recent(INTL_FEEDS["politics"], hours=args.hours, top=1) or [None])[0],
        "economy": (pick_recent(INTL_FEEDS["economy"], hours=args.hours, top=1) or [None])[0],
    }

    # fallback cho từng mảng quốc tế nếu feed chính rỗng
    if not intl["ai"]:
        intl["ai"] = (pick_recent(INTL_FALLBACK_FEEDS["ai"], hours=args.hours, top=1) or [None])[0]
    if not intl["politics"]:
        intl["politics"] = (pick_recent(INTL_FALLBACK_FEEDS["politics"], hours=args.hours, top=1) or [None])[0]
    if not intl["economy"]:
        intl["economy"] = (pick_recent(INTL_FALLBACK_FEEDS["economy"], hours=args.hours, top=1) or [None])[0]

    message = build_message(vn_all, intl)

    out_dir = Path(args.out_dir)
    out_dir.mkdir(parents=True, exist_ok=True)
    ts = datetime.now(TZ_VN).strftime("%Y-%m-%d_%H-%M")
    report_file = out_dir / f"zalo_morning_{ts}.md"
    latest_file = out_dir / "latest_message.txt"
    report_file.write_text(message, encoding="utf-8")
    latest_file.write_text(message, encoding="utf-8")

    print(json.dumps({
        "ok": True,
        "reportFile": str(report_file),
        "messageFile": str(latest_file),
        "countDomestic": len(vn_all),
        "hasAI": intl["ai"] is not None,
        "hasPolitics": intl["politics"] is not None,
        "hasEconomy": intl["economy"] is not None,
    }, ensure_ascii=False))


if __name__ == "__main__":
    main()
