#!/usr/bin/env python3
import json
import re
from datetime import datetime
from urllib.request import Request, urlopen

URL = "https://www.pvoil.com.vn/tin-gia-xang-dau"


def fetch_html(url: str) -> str:
    req = Request(url, headers={"User-Agent": "Mozilla/5.0"})
    with urlopen(req, timeout=20) as r:
        return r.read().decode("utf-8", errors="ignore")


def clean(s: str) -> str:
    s = re.sub(r"<[^>]+>", " ", s)
    s = re.sub(r"\s+", " ", s).strip()
    return s


def parse(html: str):
    # lấy tiêu đề thời gian hiệu lực
    m_time = re.search(r"<strong>\s*Giá điều chỉnh lúc[^<]+</strong>", html, re.I)
    effective = clean(m_time.group(0)) if m_time else ""

    # parse từng dòng mặt hàng
    # pattern dựa trên cấu trúc bảng hiện tại ở pvoil
    rows = re.findall(r"<tr[^>]*>(.*?)</tr>", html, flags=re.I | re.S)
    items = []
    for row in rows:
        tds = re.findall(r"<td[^>]*>(.*?)</td>", row, flags=re.I | re.S)
        if len(tds) < 4:
            continue
        product = clean(tds[1])
        price = clean(tds[2])
        change = clean(tds[3])
        if not product:
            continue
        if any(k in product.lower() for k in ["ron", "dầu", "do", "ko", "e5", "e10"]):
            items.append({
                "product": product,
                "price_vnd_per_liter": price,
                "change": change,
            })

    # dedup theo tên mặt hàng
    seen = set()
    uniq = []
    for it in items:
        key = it["product"].lower()
        if key in seen:
            continue
        seen.add(key)
        uniq.append(it)

    note_match = re.search(r"\(Giá trên đã bao gồm[^\)]+\)", html, re.I)
    note = clean(note_match.group(0)) if note_match else ""

    return effective, uniq, note


def main():
    out = {
        "ok": True,
        "generated_at": datetime.now().isoformat(timespec="seconds"),
        "source": "PVOIL",
        "source_url": URL,
    }
    try:
        html = fetch_html(URL)
        effective, items, note = parse(html)
        if not items:
            raise RuntimeError("Không parse được bảng giá xăng dầu")
        out["effective_time_text"] = effective
        out["items"] = items
        out["note"] = note
    except Exception as e:
        out["ok"] = False
        out["error"] = str(e)

    print(json.dumps(out, ensure_ascii=False))


if __name__ == "__main__":
    main()
