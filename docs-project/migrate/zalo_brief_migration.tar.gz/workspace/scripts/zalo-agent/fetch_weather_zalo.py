#!/usr/bin/env python3
import argparse
import json
import time
import urllib.parse
import urllib.request
from datetime import datetime

DEFAULT_LOCATION = "Ha Long, Quang Ninh"

# fallback to avoid geocoding miss for common VN locations
LOCATION_HINTS = {
    "ha long": (20.95045, 107.07336, "Ha Long, Quang Ninh, Vietnam"),
    "hạ long": (20.95045, 107.07336, "Ha Long, Quang Ninh, Vietnam"),
    "ha noi": (21.0245, 105.84117, "Ha Noi, Vietnam"),
    "hà nội": (21.0245, 105.84117, "Ha Noi, Vietnam"),
    "da nang": (16.0544, 108.2022, "Da Nang, Vietnam"),
    "đà nẵng": (16.0544, 108.2022, "Da Nang, Vietnam"),
    "ho chi minh": (10.8231, 106.6297, "Ho Chi Minh City, Vietnam"),
    "hồ chí minh": (10.8231, 106.6297, "Ho Chi Minh City, Vietnam"),
    "hcm": (10.8231, 106.6297, "Ho Chi Minh City, Vietnam"),
    "tp hcm": (10.8231, 106.6297, "Ho Chi Minh City, Vietnam"),
}

WEATHER_CODE_VI = {
    0: "Trời quang", 1: "Khá quang", 2: "Ít mây", 3: "Nhiều mây",
    45: "Sương mù", 48: "Sương mù đóng băng",
    51: "Mưa phùn nhẹ", 53: "Mưa phùn vừa", 55: "Mưa phùn nặng hạt",
    61: "Mưa nhẹ", 63: "Mưa vừa", 65: "Mưa to",
    80: "Mưa rào nhẹ", 81: "Mưa rào vừa", 82: "Mưa rào to",
    95: "Dông", 96: "Dông có mưa đá nhẹ", 99: "Dông có mưa đá mạnh",
}


def fetch_json(url: str, timeout: int = 15, retries: int = 2):
    last_err = None
    for i in range(retries + 1):
        try:
            req = urllib.request.Request(url, headers={"User-Agent": "Mozilla/5.0"})
            with urllib.request.urlopen(req, timeout=timeout) as r:
                return json.loads(r.read().decode("utf-8", errors="ignore"))
        except Exception as e:
            last_err = e
            if i < retries:
                time.sleep(0.6 * (i + 1))
    raise last_err


def geocode_open_meteo(location: str):
    # try http first to reduce TLS issues in some environments
    base_urls = [
        "http://geocoding-api.open-meteo.com/v1/search",
        "https://geocoding-api.open-meteo.com/v1/search",
    ]
    queries = [location, location.split(",")[0].strip()]

    for q in queries:
        for base in base_urls:
            try:
                url = base + "?" + urllib.parse.urlencode(
                    {"name": q, "count": 1, "language": "en", "format": "json"}
                )
                g = fetch_json(url, timeout=12, retries=1)
                results = g.get("results") or []
                if results:
                    loc = results[0]
                    return (
                        float(loc["latitude"]),
                        float(loc["longitude"]),
                        ", ".join([x for x in [loc.get("name"), loc.get("admin1"), loc.get("country")] if x]) or location,
                    )
            except Exception:
                continue

    # hardcoded fallback for common places
    low = location.lower()
    for k, v in LOCATION_HINTS.items():
        if k in low:
            return v

    raise RuntimeError("Không geocode được địa điểm")


def weather_open_meteo(location: str):
    lat, lon, display_name = geocode_open_meteo(location)

    forecast_bases = [
        "http://api.open-meteo.com/v1/forecast",
        "https://api.open-meteo.com/v1/forecast",
    ]

    last_err = None
    for base in forecast_bases:
        try:
            url = base + "?" + urllib.parse.urlencode(
                {
                    "latitude": lat,
                    "longitude": lon,
                    "current": "temperature_2m,relative_humidity_2m,wind_speed_10m,apparent_temperature,weather_code",
                    "daily": "temperature_2m_max,temperature_2m_min,precipitation_probability_max",
                    "timezone": "Asia/Bangkok",
                    "forecast_days": 1,
                }
            )
            w = fetch_json(url, timeout=12, retries=1)

            cur = w.get("current") or {}
            daily = w.get("daily") or {}
            code = cur.get("weather_code")
            desc = WEATHER_CODE_VI.get(code, "Thời tiết thay đổi")

            tmin = (daily.get("temperature_2m_min") or ["?"])[0]
            tmax = (daily.get("temperature_2m_max") or ["?"])[0]
            rain = (daily.get("precipitation_probability_max") or ["?"])[0]

            return {
                "ok": True,
                "source": "open-meteo",
                "source_url": url,
                "location": display_name,
                "current": {
                    "description": desc,
                    "temp_c": str(cur.get("temperature_2m", "?")),
                    "feels_like_c": str(cur.get("apparent_temperature", "?")),
                    "humidity_pct": str(cur.get("relative_humidity_2m", "?")),
                    "wind_kmph": str(cur.get("wind_speed_10m", "?")),
                },
                "today": {
                    "min_c": str(tmin),
                    "max_c": str(tmax),
                    "chance_rain_pct": rain,
                },
                "confidence": "high",
            }
        except Exception as e:
            last_err = e

    raise RuntimeError(str(last_err) if last_err else "Open-Meteo lỗi")


def weather_wttr(location: str):
    base_urls = [
        "http://wttr.in/",
        "https://wttr.in/",
    ]
    last_err = None
    for base in base_urls:
        try:
            url = base + urllib.parse.quote(location) + "?format=j1"
            data = fetch_json(url, timeout=12, retries=1)
            current = (data.get("current_condition") or [{}])[0]
            today = (data.get("weather") or [{}])[0]

            desc = ((current.get("weatherDesc") or [{}])[0].get("value") or "Nhiều mây").strip()
            temp_c = current.get("temp_C") or "?"
            feels_c = current.get("FeelsLikeC") or "?"
            humidity = current.get("humidity") or "?"
            wind_kmph = current.get("windspeedKmph") or "?"
            tmin = today.get("mintempC") or "?"
            tmax = today.get("maxtempC") or "?"

            chance_rain = 0
            for h in (today.get("hourly") or []):
                try:
                    chance_rain = max(chance_rain, int(h.get("chanceofrain") or 0))
                except Exception:
                    pass

            return {
                "ok": True,
                "source": "wttr.in",
                "source_url": url,
                "location": location,
                "current": {
                    "description": desc,
                    "temp_c": str(temp_c),
                    "feels_like_c": str(feels_c),
                    "humidity_pct": str(humidity),
                    "wind_kmph": str(wind_kmph),
                },
                "today": {
                    "min_c": str(tmin),
                    "max_c": str(tmax),
                    "chance_rain_pct": chance_rain,
                },
                "confidence": "medium",
            }
        except Exception as e:
            last_err = e
    raise RuntimeError(str(last_err) if last_err else "wttr lỗi")


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--location", default=DEFAULT_LOCATION)
    args = ap.parse_args()

    out = {
        "ok": False,
        "generated_at": datetime.now().isoformat(timespec="seconds"),
        "location": args.location,
    }

    errors = []
    for fn in (weather_open_meteo, weather_wttr):
        try:
            data = fn(args.location)
            out.update(data)
            out["ok"] = True
            break
        except Exception as e:
            errors.append(f"{fn.__name__}: {e}")

    if out.get("ok"):
        c = out["current"]
        t = out["today"]
        out["text"] = (
            f"🌤️ {out['location']}: {c['description']}; "
            f"{t['min_c']}–{t['max_c']}°C (hiện tại {c['temp_c']}°C, cảm giác {c['feels_like_c']}°C); "
            f"độ ẩm {c['humidity_pct']}%; gió {c['wind_kmph']} km/h; mưa ~{t['chance_rain_pct']}%."
        )
        if errors:
            out["fallback_errors"] = errors
    else:
        out["error"] = " | ".join(errors) if errors else "Không lấy được dữ liệu thời tiết"

    print(json.dumps(out, ensure_ascii=False))


if __name__ == "__main__":
    main()
