#!/usr/bin/env python3
import argparse
import json
import xml.etree.ElementTree as ET
from urllib.request import Request, urlopen
from urllib.parse import urlencode
from datetime import datetime

VCB_XML = "https://portal.vietcombank.com.vn/Usercontrols/TVPortal.TyGia/pXML.aspx?b=68"
FREE_FOREX_API = "https://www.freeforexapi.com/api/live?pairs=USDVND"
OPEN_ER_API = "https://open.er-api.com/v6/latest/USD"
SJC_API = "https://sjc.com.vn/GoldPrice/Services/PriceService.ashx"


def http_get(url: str, timeout: int = 20) -> str:
    req = Request(url, headers={"User-Agent": "Mozilla/5.0"})
    with urlopen(req, timeout=timeout) as r:
        return r.read().decode("utf-8", errors="ignore")


def http_post_form(url: str, data: dict, timeout: int = 20) -> str:
    payload = urlencode(data).encode("utf-8")
    req = Request(
        url,
        data=payload,
        headers={
            "User-Agent": "Mozilla/5.0",
            "Content-Type": "application/x-www-form-urlencoded; charset=UTF-8",
        },
        method="POST",
    )
    with urlopen(req, timeout=timeout) as r:
        return r.read().decode("utf-8", errors="ignore")


def fetch_usd_vnd_vcb() -> dict:
    raw = http_get(VCB_XML)
    root = ET.fromstring(raw)
    dt = (root.findtext("DateTime") or "").strip()
    usd = None
    for ex in root.findall("Exrate"):
        if (ex.attrib.get("CurrencyCode") or "").upper() == "USD":
            usd = {
                "currency": "USD",
                "buy": ex.attrib.get("Buy"),
                "transfer": ex.attrib.get("Transfer"),
                "sell": ex.attrib.get("Sell"),
            }
            break
    if not usd:
        raise RuntimeError("Không tìm thấy USD trong XML Vietcombank")
    return {
        "source": "Vietcombank",
        "source_url": VCB_XML,
        "updated_at": dt,
        "usd_vnd": usd,
    }


def fetch_usd_vnd_freeforex() -> dict:
    raw = http_get(FREE_FOREX_API)
    data = json.loads(raw)
    rates = data.get("rates") or {}
    pair = rates.get("USDVND") or {}
    rate = pair.get("rate")
    if rate is None:
        raise RuntimeError("FreeForexAPI không trả về rate cho USDVND")

    # FreeForex là mid-rate, map buy/transfer/sell cùng giá để trả lời nhanh
    rate_str = f"{float(rate):.2f}"
    return {
        "source": "FreeForexAPI",
        "source_url": FREE_FOREX_API,
        "updated_at": pair.get("timestamp") or datetime.now().isoformat(timespec="seconds"),
        "usd_vnd": {
            "currency": "USD",
            "buy": rate_str,
            "transfer": rate_str,
            "sell": rate_str,
            "type": "mid",
        },
    }


def fetch_usd_vnd_open_er() -> dict:
    raw = http_get(OPEN_ER_API)
    data = json.loads(raw)
    if data.get("result") != "success":
        raise RuntimeError(f"open.er-api lỗi: {data.get('result')}")

    rates = data.get("rates") or {}
    rate = rates.get("VND")
    if rate is None:
        raise RuntimeError("open.er-api không có VND")

    rate_str = f"{float(rate):.2f}"
    return {
        "source": "open.er-api",
        "source_url": OPEN_ER_API,
        "updated_at": data.get("time_last_update_utc") or datetime.now().isoformat(timespec="seconds"),
        "usd_vnd": {
            "currency": "USD",
            "buy": rate_str,
            "transfer": rate_str,
            "sell": rate_str,
            "type": "mid",
        },
    }


def fetch_usd_vnd_with_fallback() -> tuple[dict, list]:
    errors = []
    for fn in (fetch_usd_vnd_vcb, fetch_usd_vnd_freeforex, fetch_usd_vnd_open_er):
        try:
            return fn(), errors
        except Exception as e:
            errors.append(str(e))
    raise RuntimeError(" | ".join(errors) if errors else "Không lấy được USD/VND")


def fetch_sjc_gold(branch_id: int = 1) -> dict:
    raw = http_post_form(SJC_API, {"method": "GetCurrentGoldPricesByBranch", "BranchId": str(branch_id)})
    data = json.loads(raw)
    if not data.get("success"):
        raise RuntimeError("SJC API trả về success=false")
    items = data.get("data") or []

    # ưu tiên dòng vàng miếng SJC 1L/10L/1KG
    target = None
    for it in items:
        t = (it.get("TypeName") or "").lower()
        if "vàng sjc 1l" in t or "1kg" in t:
            target = it
            break
    if target is None and items:
        target = items[0]

    return {
        "source": "SJC",
        "source_url": SJC_API,
        "updated_at": data.get("latestDate"),
        "branch_id": branch_id,
        "branch_name": (target or {}).get("BranchName"),
        "type_name": (target or {}).get("TypeName"),
        "buy": (target or {}).get("Buy"),
        "sell": (target or {}).get("Sell"),
    }


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--mode", choices=["fx", "gold", "all"], default="all")
    ap.add_argument("--branch-id", type=int, default=1, help="SJC branch id, mặc định 1=HCM")
    args = ap.parse_args()

    out = {
        "ok": True,
        "generated_at": datetime.now().isoformat(timespec="seconds"),
    }

    try:
        if args.mode in ("fx", "all"):
            fx, fx_errors = fetch_usd_vnd_with_fallback()
            out["fx"] = fx
            if fx_errors:
                out["fx_fallback_errors"] = fx_errors
    except Exception as e:
        out["ok"] = False
        out["fx_error"] = str(e)

    try:
        if args.mode in ("gold", "all"):
            out["gold"] = fetch_sjc_gold(args.branch_id)
    except Exception as e:
        out["ok"] = False
        out["gold_error"] = str(e)

    print(json.dumps(out, ensure_ascii=False))


if __name__ == "__main__":
    main()
