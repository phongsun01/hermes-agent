#!/usr/bin/env python3
"""
Code-first dispatcher for Zalo inbound messages.
- Detect intents: weather / usd-fx / gold / fuel
- Execute local Python scripts directly
- Return JSON for agent consumption

Usage:
  python3 scripts/zalo_codefirst_dispatch.py --message "giá vàng hôm nay"
"""

from __future__ import annotations

import argparse
import json
import os
import re
import subprocess
import sys
from datetime import datetime
from pathlib import Path
from urllib.request import Request, urlopen

BASE = Path("/Users/xitrum/.openclaw/workspace/scripts/zalo-agent")
EXA_SEARCH_SCRIPT = Path("/Users/xitrum/.openclaw/workspace/scripts/web/exa_search.mjs")
SKILL_EXAMPLES_DIR = Path("/Users/xitrum/.openclaw/workspace/research/claude-learning/markdown-skill-pack-v1/examples")
POLICY_AUDIT_LOG = Path("/Users/xitrum/.openclaw/workspace/logs/skill_policy_guard.log")
SKILL_POLICY_ENFORCE = os.getenv("SKILL_POLICY_ENFORCE", "1") == "1"
SKILL_POLICY_FAIL_MODE = os.getenv("SKILL_POLICY_FAIL_MODE", "open").lower()  # open|closed


def run_cmd(cmd: list[str], timeout: int = 25) -> str:
    p = subprocess.run(cmd, capture_output=True, text=True, timeout=timeout)
    if p.returncode != 0:
        raise RuntimeError((p.stderr or p.stdout or "script failed").strip())
    return (p.stdout or "").strip()


def normalize(s: str) -> str:
    s = (s or "").strip().lower()
    s = re.sub(r"\s+", " ", s)
    return s


def detect_location(msg: str) -> str:
    m = normalize(msg)
    
    # Common VN cities
    if any(k in m for k in ["hạ long", "ha long", "halong"]):
        return "Hạ Long"
    if any(k in m for k in ["hà nội", "ha noi", "hanoi"]):
        return "Hà Nội"
    if any(k in m for k in ["đà nẵng", "da nang", "danang"]):
        return "Đà Nẵng"
    if any(k in m for k in ["hồ chí minh", "ho chi minh", "hcm", "sài gòn", "saigon"]):
        return "Hồ Chí Minh"
    if any(k in m for k in ["cần thơ", "can tho"]):
        return "Cần Thơ"
    if any(k in m for k in ["huế", "hue"]):
        return "Huế"
    if any(k in m for k in ["nha trang"]):
        return "Nha Trang"
    if any(k in m for k in ["vũng tàu", "vung tau"]):
        return "Vũng Tàu"
    
    # Extract location after weather keywords
    weather_kw = ["thời tiết", "weather", "nhiệt độ"]
    for kw in weather_kw:
        if kw in m:
            parts = m.split(kw, 1)
            if len(parts) > 1:
                loc = parts[1].strip()
                if loc:
                    return loc.title()
    
    # Default fallback
    return "Hạ Long"


def detect_intent(msg: str) -> str | None:
    m = normalize(msg)

    if re.search(r"^/?duty\s+(on|off|status)\b", m):
        return "duty"

    weather_kw = ["thời tiết", "weather", "nhiệt độ", "trời", "mưa"]
    usd_kw = ["usd", "tỷ giá", "đô", "usd/vnd", "đô la"]
    gold_kw = ["giá vàng", "vàng sjc", "vàng hôm nay", "vàng"]
    fuel_kw = ["giá xăng", "xăng", "xăng dầu", "xăng hôm nay"]
    lottery_kw = ["xổ số", "xoso", "kqxs", "xsmb", "miền bắc", "kết quả số", "kết quả xổ số"]
    notion_kw = ["notion", "kiểm tra", "lịch kiểm tra", "đoàn kiểm tra", "inspection"]

    if any(k in m for k in weather_kw):
        return "weather"
    if any(k in m for k in usd_kw):
        return "fx"
    if any(k in m for k in gold_kw):
        return "gold"
    if any(k in m for k in fuel_kw):
        return "fuel"
    if any(k in m for k in lottery_kw):
        return "lottery"
    if any(k in m for k in notion_kw):
        return "inspection_notion"
    return None


def parse_duty_mode(msg: str) -> str:
    m = normalize(msg)
    mm = re.search(r"^/?duty\s+(on|off|status)\b", m)
    return (mm.group(1) if mm else "status")


def wants_web_lookup(msg: str) -> bool:
    m = normalize(msg)
    web_kw = [
        "mở web search",
        "web search",
        "tra web",
        "tra cứu web",
        "kiểm tra website",
        "check website",
        "nguồn chính thức",
        "đối chiếu nguồn",
        "web_fetch",
    ]
    return any(k in m for k in web_kw)


def fetch_text(url: str, timeout: int = 20) -> str:
    req = Request(url, headers={"User-Agent": "Mozilla/5.0"})
    with urlopen(req, timeout=timeout) as r:
        return r.read().decode("utf-8", errors="ignore")


def parse_pvoil_effective(html: str) -> str:
    m = re.search(r"Giá điều chỉnh lúc\s*[^<\n]+", html, re.I)
    return (m.group(0).strip() if m else "")


def exa_search(query: str, count: int = 5) -> dict:
    if not EXA_SEARCH_SCRIPT.exists():
        return {"ok": False, "error": "missing_exa_search_script"}
    try:
        out = run_cmd([
            "node",
            str(EXA_SEARCH_SCRIPT),
            query,
            "--count",
            str(count),
        ], timeout=30)
        data = json.loads(out)
        # exa_search.mjs returns raw payload: {requestId, results, ...}
        if isinstance(data, dict):
            data.setdefault("ok", isinstance(data.get("results"), list))
        return data
    except Exception as e:
        return {"ok": False, "error": str(e)[:220]}


def _load_phasea_skill(skill_id: str) -> dict | None:
    """Load one markdown skill frontmatter/body from Phase A prototype path."""
    skills_dir = Path("/Users/xitrum/.openclaw/workspace/scripts/skills")
    if str(skills_dir) not in sys.path:
        sys.path.insert(0, str(skills_dir))
    try:
        from markdown_skill_loader import MarkdownSkillLoader
    except Exception:
        return None

    loader = MarkdownSkillLoader(SKILL_EXAMPLES_DIR)
    items = {s.id: s for s in loader.load()}
    rec = items.get(skill_id)
    if not rec:
        return None
    return {"id": rec.id, "frontmatter": rec.frontmatter, "body": rec.body}


def _audit_policy(*, message: str, intent: str, skill_id: str, tool_name: str, allowed: bool, reason: str, mode: str = "enforce") -> None:
    try:
        POLICY_AUDIT_LOG.parent.mkdir(parents=True, exist_ok=True)
        rec = {
            "ts": datetime.now().isoformat(timespec="seconds"),
            "intent": intent,
            "skill_id": skill_id,
            "tool": tool_name,
            "allowed": allowed,
            "reason": reason,
            "mode": mode,
            "message_preview": (message or "")[:120],
        }
        with POLICY_AUDIT_LOG.open("a", encoding="utf-8") as f:
            f.write(json.dumps(rec, ensure_ascii=False) + "\n")
    except Exception:
        pass


def _policy_allow(skill: dict | None, tool_name: str, *, remote: bool = False, owner: bool = False, channel: str = "zalo") -> tuple[bool, str]:
    """Return (is_allowed, reason_code) using Tool Policy Guard with configurable fail mode.

    - fail-open (default): guard errors do not block runtime
    - fail-closed: guard errors block runtime
    """
    if not skill:
        return True, "NO_SKILL_POLICY"

    skills_dir = Path("/Users/xitrum/.openclaw/workspace/scripts/skills")
    if str(skills_dir) not in sys.path:
        sys.path.insert(0, str(skills_dir))
    try:
        from tool_policy_guard import GuardContext, decide_tool_call
    except Exception:
        if SKILL_POLICY_FAIL_MODE == "closed":
            return False, "GUARD_UNAVAILABLE_FAIL_CLOSED"
        return True, "GUARD_UNAVAILABLE_FAIL_OPEN"

    try:
        fm = skill.get("frontmatter", {}) or {}
        d = decide_tool_call(
            ctx=GuardContext(channel=channel, is_remote=remote, sender_is_owner=owner, tool_name=tool_name),
            allowed_tools=fm.get("allowed_tools", []) or [],
            denied_tools=fm.get("denied_tools", []) or [],
            remote_invocable=bool(fm.get("remote_invocable", False)),
            owner_only=bool(fm.get("owner_only", False)),
        )
        return d.decision == "ALLOW", d.reason_code
    except Exception:
        if SKILL_POLICY_FAIL_MODE == "closed":
            return False, "GUARD_RUNTIME_ERROR_FAIL_CLOSED"
        return True, "GUARD_RUNTIME_ERROR_FAIL_OPEN"


def detect_inspection_mode(msg: str) -> str:
    m = normalize(msg)
    # explicit phrases first
    if any(k in m for k in ["xong", "hoàn thành", "done", "eod", "cuối ngày"]):
        return "eod_done"
    if any(k in m for k in ["ngày mai", "mai", "tomorrow"]):
        return "tomorrow"
    if any(k in m for k in ["chiều", "afternoon", "hôm nay chiều"]):
        return "afternoon"
    if any(k in m for k in ["sáng", "morning", "hôm nay"]):
        return "morning"
    # default watch mode
    return "changes_watch"


def dispatch(message: str) -> dict:
    intent = detect_intent(message)
    if not intent:
        return {"handled": False, "reason": "no_match"}

    try:
        if intent == "duty":
            mode = parse_duty_mode(message)
            if mode == "status":
                out = run_cmd([
                    "/usr/bin/python3",
                    str(BASE / "zalo_receptionist_state.py"),
                    "status",
                ])
            else:
                out = run_cmd([
                    "/usr/bin/python3",
                    str(BASE / "zalo_receptionist_state.py"),
                    "duty",
                    mode,
                ])
            return {"handled": True, "intent": intent, "reply": out, "mode": mode}

        if intent == "weather":
            skill = _load_phasea_skill("weather-brief")
            ok, reason = _policy_allow(skill, "web_fetch", remote=False, owner=False, channel="zalo")
            sid = (skill or {}).get("id", "weather-brief")
            _audit_policy(message=message, intent=intent, skill_id=sid, tool_name="web_fetch", allowed=ok, reason=reason, mode=("enforce" if SKILL_POLICY_ENFORCE else "monitor"))
            if SKILL_POLICY_ENFORCE and not ok:
                return {"handled": True, "intent": intent, "reply": f"⚠️ Policy block: {reason}", "policy_block": reason}

            location = detect_location(message)
            out = run_cmd([
                "/usr/bin/python3",
                str(BASE / "fetch_weather_zalo.py"),
                "--location",
                location,
            ])
            # Extract text field from JSON for cleaner agent consumption
            try:
                weather_data = json.loads(out)
                if weather_data.get("ok") and weather_data.get("text"):
                    return {"handled": True, "intent": intent, "reply": weather_data["text"], "location": location}
            except Exception:
                pass
            return {"handled": True, "intent": intent, "reply": out, "location": location}

        if intent == "fx":
            skill = _load_phasea_skill("vn-fx-rate")
            ok, reason = _policy_allow(skill, "web_fetch", remote=False, owner=False, channel="zalo")
            sid = (skill or {}).get("id", "vn-fx-rate")
            _audit_policy(message=message, intent=intent, skill_id=sid, tool_name="web_fetch", allowed=ok, reason=reason, mode=("enforce" if SKILL_POLICY_ENFORCE else "monitor"))
            if SKILL_POLICY_ENFORCE and not ok:
                return {"handled": True, "intent": intent, "reply": f"⚠️ Policy block: {reason}", "policy_block": reason}

            out = run_cmd([
                "/usr/bin/python3",
                str(BASE / "fetch_vn_market_rates.py"),
                "--mode",
                "fx",
            ])
            # Format FX JSON into readable text
            try:
                fx_data = json.loads(out)
                if fx_data.get("ok") and fx_data.get("fx"):
                    fx = fx_data["fx"]
                    usd = fx.get("usd_vnd", {})
                    text = f"💵 Tỷ giá USD/VND ({fx.get('source', 'N/A')})\n"
                    text += f"Mua: {usd.get('buy', 'N/A')} | Chuyển khoản: {usd.get('transfer', 'N/A')} | Bán: {usd.get('sell', 'N/A')}\n"
                    text += f"Cập nhật: {fx.get('updated_at', 'N/A')}"
                    return {"handled": True, "intent": intent, "reply": text}
            except Exception:
                pass
            return {"handled": True, "intent": intent, "reply": out}

        if intent == "gold":
            skill = _load_phasea_skill("vn-gold-price")
            ok, reason = _policy_allow(skill, "web_fetch", remote=False, owner=False, channel="zalo")
            sid = (skill or {}).get("id", "vn-gold-price")
            _audit_policy(message=message, intent=intent, skill_id=sid, tool_name="web_fetch", allowed=ok, reason=reason, mode=("enforce" if SKILL_POLICY_ENFORCE else "monitor"))
            if SKILL_POLICY_ENFORCE and not ok:
                return {"handled": True, "intent": intent, "reply": f"⚠️ Policy block: {reason}", "policy_block": reason}

            out = run_cmd([
                "/usr/bin/python3",
                str(BASE / "fetch_vn_market_rates.py"),
                "--mode",
                "gold",
            ])
            # Format gold JSON into readable text
            try:
                gold_data = json.loads(out)
                if gold_data.get("ok") and gold_data.get("gold"):
                    g = gold_data["gold"]
                    text = f"🪙 Giá vàng {g.get('type_name', 'SJC')} ({g.get('branch_name', 'N/A')})\n"
                    text += f"Mua: {g.get('buy', 'N/A')} | Bán: {g.get('sell', 'N/A')}\n"
                    text += f"Cập nhật: {g.get('updated_at', 'N/A')}"
                    return {"handled": True, "intent": intent, "reply": text}
            except Exception:
                pass
            return {"handled": True, "intent": intent, "reply": out}

        if intent == "fuel":
            skill = _load_phasea_skill("vn-fuel-price")
            ok, reason = _policy_allow(skill, "web_fetch", remote=False, owner=False, channel="zalo")
            sid = (skill or {}).get("id", "vn-fuel-price")
            _audit_policy(message=message, intent=intent, skill_id=sid, tool_name="web_fetch", allowed=ok, reason=reason, mode=("enforce" if SKILL_POLICY_ENFORCE else "monitor"))
            if SKILL_POLICY_ENFORCE and not ok:
                return {"handled": True, "intent": intent, "reply": f"⚠️ Policy block: {reason}", "policy_block": reason}

            # Always get baseline from internal script first (script-first).
            out = run_cmd([
                "/usr/bin/python3",
                str(BASE / "fetch_vn_fuel_prices.py"),
            ])

            # Hard override: if user explicitly asks web lookup, do web check here
            # so LLM cannot fall back to refusal template.
            if wants_web_lookup(message):
                pvoil_url = "https://www.pvoil.com.vn/tin-gia-xang-dau"
                try:
                    html = fetch_text(pvoil_url, timeout=20)
                    effective = parse_pvoil_effective(html)
                except Exception:
                    effective = ""

                try:
                    baseline = json.loads(out)
                except Exception:
                    baseline = {"raw": out}

                # EXA web search for explicit web-lookup override
                exa = exa_search("giá xăng dầu Việt Nam mới nhất PVOIL Bộ Công Thương", count=5)
                exa_items = []
                if isinstance(exa, dict) and exa.get("ok"):
                    for r in (exa.get("results") or [])[:3]:
                        exa_items.append({
                            "title": r.get("title", ""),
                            "url": r.get("url", ""),
                            "publishedDate": r.get("publishedDate", ""),
                        })

                reply_obj = {
                    "ok": True,
                    "mode": "fuel_web_override_exa",
                    "note": "Đã tra web theo yêu cầu user và đối chiếu baseline script.",
                    "web_source": pvoil_url,
                    "web_effective_time_text": effective,
                    "exa": {
                        "ok": bool(isinstance(exa, dict) and exa.get("ok")),
                        "top_results": exa_items,
                        "error": (exa.get("error") if isinstance(exa, dict) else "")
                    },
                    "script_baseline": baseline,
                }
                return {"handled": True, "intent": intent, "reply": json.dumps(reply_obj, ensure_ascii=False)}

            # Format fuel JSON into readable text for non-web case
            try:
                fuel_data = json.loads(out)
                if fuel_data.get("ok") and fuel_data.get("items"):
                    lines = ["⛽ Giá xăng dầu Việt Nam"]
                    if fuel_data.get("effective_time_text"):
                        lines.append(fuel_data["effective_time_text"])
                    for item in (fuel_data.get("items") or [])[:5]:
                        product = item.get("product", "")
                        price = item.get("price_vnd_per_liter", "N/A")
                        lines.append(f"- {product}: {price}")
                    if fuel_data.get("source"):
                        lines.append(f"Nguồn: {fuel_data.get('source')}")
                    return {"handled": True, "intent": intent, "reply": "\n".join(lines)}
            except Exception:
                pass
            return {"handled": True, "intent": intent, "reply": out}

        if intent == "lottery":
            skill = _load_phasea_skill("vn-lottery")
            ok, reason = _policy_allow(skill, "web_fetch", remote=False, owner=False, channel="zalo")
            sid = (skill or {}).get("id", "vn-lottery")
            _audit_policy(message=message, intent=intent, skill_id=sid, tool_name="web_fetch", allowed=ok, reason=reason, mode=("enforce" if SKILL_POLICY_ENFORCE else "monitor"))
            if SKILL_POLICY_ENFORCE and not ok:
                return {"handled": True, "intent": intent, "reply": f"⚠️ Policy block: {reason}", "policy_block": reason}

            out = run_cmd([
                "/usr/bin/python3",
                str(BASE / "fetch_lottery_zalo.py"),
                "--region",
                "xsmb",
            ])
            return {"handled": True, "intent": intent, "reply": out}

        if intent == "inspection_notion":
            mode = detect_inspection_mode(message)
            out = run_cmd([
                "/usr/bin/python3",
                "/Users/xitrum/.openclaw/workspace/scripts/inspection/inspection_schedule_notifier.py",
                "--mode",
                mode,
                "--json",
            ])
            # Keep message short and deterministic
            try:
                data = json.loads(out)
                if data.get("ok"):
                    cnt = int(data.get("count", 0) or 0)
                    if mode == "changes_watch":
                        if cnt == 0:
                            reply = "ℹ️ Em đã kết nối Notion OK, hiện chưa có thay đổi lịch kiểm tra mới."
                        else:
                            reply = f"✅ Em đã đọc Notion OK. Có {cnt} thay đổi lịch kiểm tra mới."
                    elif cnt == 0:
                        labels = {
                            "morning": "sáng nay",
                            "afternoon": "chiều nay",
                            "tomorrow": "ngày mai",
                            "eod_done": "cuối ngày",
                        }
                        reply = f"ℹ️ Em đã kiểm tra Notion, hiện chưa có lịch {labels.get(mode, 'phù hợp')} để báo."
                    else:
                        # Return concise first event preview
                        first = (data.get("events") or [{}])[0]
                        text = (first.get("text") or "").strip()
                        short = text.splitlines()[0] if text else "Có lịch kiểm tra mới."
                        reply = f"✅ {short}"
                else:
                    reply = "⚠️ Em đọc Notion chưa thành công, em đang retry lại."
            except Exception:
                reply = "✅ Em đã gọi kiểm tra Notion."
            return {"handled": True, "intent": intent, "mode": mode, "reply": reply}

        return {"handled": False, "reason": "unsupported_intent"}
    except Exception as e:
        return {
            "handled": True,
            "intent": intent,
            "reply": "Dạ em tạm thời chưa lấy được dữ liệu. Anh thử lại sau ít phút giúp em nhé.",
            "error": str(e)[:300],
        }


def main() -> None:
    ap = argparse.ArgumentParser(description="Code-first dispatcher for Zalo intents")
    ap.add_argument("--message", required=True)
    args = ap.parse_args()
    print(json.dumps(dispatch(args.message), ensure_ascii=False))


if __name__ == "__main__":
    main()
